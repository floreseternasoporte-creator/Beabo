@echo off
rem ============================================================
rem  Drex Studio 1.1 — Launcher para Windows
rem  Abre la aplicacion en tu navegador predeterminado.
rem  Requiere conexion a internet (el backend de Drex es online).
rem  Novedades 1.1: editor de 3 paneles, 6 plantillas, capas,
rem  timeline con keyframes, libreria de assets, mock de telefono,
rem  lista de verificacion de publicacion, historial de versiones
rem  y 4 idiomas (ES/EN/ZH/PT).
rem ============================================================
start "" "%~dp0index.html"
