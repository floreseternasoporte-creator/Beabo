DREX STUDIO 1.1 — GUÍA DE INSTALACIÓN (Windows)
==================================================

¿QUÉ ES?
Drex Studio es la herramienta oficial de escritorio para crear efectos
para la cámara de Drex. Diseña capas, filtros y partículas, anima con
keyframes, escribe el código del efecto y envíalo a revisión. Los
efectos aprobados aparecen en la cámara de Drex para todos los usuarios.

NOVEDADES DE LA 1.1
- Editor profesional de 3 paneles: capas/assets · vista previa · propiedades/código.
- 6 plantillas: efecto de cara, fondo personalizado, pantalla verde
  (chroma key), mini-juego, filtro de color y distorsión.
- Capas: agregar, reordenar, mostrar/ocultar, bloquear y eliminar.
  Tipos: filtro, imagen, texto, partículas, cara y croma.
- Timeline con keyframes (posición, escala, opacidad, intensidad),
  reproducir/pausar y scrubber.
- Librería de assets: importa imágenes y audio, úsalos como capas.
- Parámetros en vivo: intensidad, color, velocidad y más, con
  actualización inmediata en la vista previa.
- Vista previa mejorada: avatar 3D, cámara con malla facial,
  cambiar de cámara, pantalla completa y mock de teléfono que muestra
  el efecto dentro de la cámara de Drex.
- Lista de verificación de publicación: el envío se bloquea hasta que
  el efecto tiene nombre, portada, descripción, vista previa probada y
  al menos una capa visible.
- Historial de versiones locales + deshacer.
- 4 idiomas: español, inglés, chino y portugués (botones arriba a la derecha).

REQUISITOS
- Windows 10 u 11
- Google Chrome o Microsoft Edge (recomendado)
- Conexión a internet (el backend de Drex funciona online)
- Cámara web (opcional, solo para la vista previa con malla facial)

INSTALACIÓN
1. Copia la carpeta "drex-studio-1.1" donde quieras
   (ej.: C:\DrexStudio o tu Escritorio).
2. Haz doble clic en "Drex-Studio.bat".
   Se abrirá la aplicación en tu navegador. ¡Listo!
   (No requiere instalación ni permisos de administrador.)

PRIMEROS PASOS
1. "Vincular mi cuenta Drex": entra con el mismo correo o nombre de
   usuario y contraseña de tu cuenta de Drex.
   - Si aún no tienes cuenta, usa "Crear cuenta de desarrollador".
     Tu cuenta quedará marcada automáticamente como desarrollador.
   - Si tu correo pide verificación, escribe el código de 6 dígitos
     que te llegue.
2. "Mis proyectos": crea un proyecto nuevo eligiendo una de las
   6 plantillas.
3. "Editor": ponle nombre y descripción, elige el tipo de efecto,
   ajusta las capas con los deslizadores de propiedades, importa
   assets, anima con keyframes en el timeline y escribe el código.
   La vista previa muestra todo en vivo.
   - "Cámara" usa tu webcam y dibuja la malla facial sobre el video.
     La primera vez descarga el modelo de reconocimiento (unos segundos).
   - "Mock teléfono" muestra el efecto dentro de un marco de teléfono,
     como se verá en la cámara de Drex.
   - NOTA: el motor v1 de la cámara de Drex aplica el filtro CSS +
     la imagen overlay. Las capas, los keyframes y el código JavaScript
     se guardan con el efecto y los usará el futuro motor v2.
4. "Enviar": completa la lista de verificación (nombre, portada,
   descripción, vista previa probada, capa visible) y pulsa
   "Enviar a revisión". Recibirás un ID y el estado
   "pendiente de revisión".
5. "Mis efectos": consulta el estado real de tus efectos
   (pendiente de revisión / publicado) y cuántas veces se han usado.

IDIOMA
La interfaz está en español, inglés, chino y portugués
(botones ES | EN | 中文 | PT arriba a la derecha).

PRIVACIDAD
Tus proyectos en borrador y el historial de versiones se guardan solo
en tu equipo (navegador). Solo los efectos que envías a revisión
viajan a los servidores de Drex.

¿PROBLEMAS?
- "Sin conexión": revisa tu internet; el inicio de sesión y el envío
  requieren conexión.
- La cámara no se activa: revisa los permisos del navegador
  (icono del candado en la barra de dirección).
- La malla facial no carga: necesita internet la primera vez para
  descargar el modelo.

© 2026 Drex
