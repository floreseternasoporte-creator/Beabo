@echo off
rem ============================================================
rem  Drex Studio 1.0 — Launcher para Windows
rem  Abre la aplicacion en tu navegador predeterminado.
rem  Requiere conexion a internet (el backend de Drex es online).
rem ============================================================
start "" "%~dp0index.html"
