DREX STUDIO 1.0 — GUÍA DE INSTALACIÓN (Windows)
==================================================

¿QUÉ ES?
Drex Studio es la herramienta oficial de escritorio para crear efectos
para la cámara de Drex. Diseña el filtro, sube tu overlay, escribe el
código del efecto y envíalo a revisión. Los efectos aprobados aparecen
en la cámara de Drex para todos los usuarios.

REQUISITOS
- Windows 10 u 11
- Google Chrome o Microsoft Edge (recomendado)
- Conexión a internet (el backend de Drex funciona online)
- Cámara web (opcional, solo para la vista previa con malla facial)

INSTALACIÓN
1. Copia la carpeta "drex-studio" donde quieras
   (ej.: C:\DrexStudio o tu Escritorio).
2. Haz doble clic en "Drex-Studio.bat".
   Se abrirá la aplicación en tu navegador. ¡Listo!
   (No requiere instalación ni permisos de administrador.)

PRIMEROS PASOS
1. "Vincular mi cuenta Drex": entra con el mismo correo o nombre de
   usuario y contraseña de tu cuenta de Drex.
   - Si aún no tienes cuenta, usa "Crear cuenta de desarrollador".
     Tu cuenta quedará marcada automáticamente como desarrollador.
   - Si tu correo pide verificación, escribe el código de 6 dígitos
     que te llegue.
2. "Mis proyectos": crea un proyecto nuevo con una plantilla
   (Efecto de cara, Efecto de juego o Desde cero).
3. "Editor": ponle nombre, ajusta el filtro con los deslizadores,
   sube tu imagen PNG con transparencia y escribe el código del efecto.
   La vista previa muestra todo en vivo.
   - "Activar cámara" usa tu webcam y dibuja la malla facial
     (478 puntos) sobre el video. La primera vez descarga el modelo
     de reconocimiento (unos segundos).
   - NOTA: el motor v1 de la cámara de Drex aplica el filtro CSS +
     la imagen overlay. El código JavaScript se guarda con el efecto
     y lo usará el futuro motor v2.
4. "Enviar": revisa el resumen y pulsa "Enviar a revisión".
   Recibirás un ID (ej.: studio_a1b2c3d4_1727...) y el estado
   "pendiente de revisión".
5. "Mis efectos": consulta el estado real de tus efectos
   (pendiente de revisión / publicado) y cuántas veces se han usado.

IDIOMA
La interfaz está en español e inglés (botones ES | EN arriba a la
derecha). El chino (ZH) y el portugués (PT) llegarán en la versión 1.1.

PRIVACIDAD
Tus proyectos en borrador se guardan solo en tu equipo (navegador).
Solo los efectos que envías a revisión viajan a los servidores de Drex.

¿PROBLEMAS?
- "Sin conexión": revisa tu internet; el inicio de sesión y el envío
  requieren conexión.
- La cámara no se activa: revisa los permisos del navegador
  (icono del candado en la barra de dirección).
- La malla facial no carga: necesita internet la primera vez para
  descargar el modelo.

© 2026 Drex
