@echo off
rem ============================================================
rem  Drex Studio 1.5 — Launcher para Windows
rem  Abre la aplicacion en tu navegador predeterminado.
rem  Requiere conexion a internet solo para publicar en Drex.
rem  Novedades 1.4: la vista previa ya NO es obligatoria para publicar
rem  (solo se piden nombre, portada y descripcion), paneles
rem  redimensionables con divisores, barra de herramientas profesional,
rem  zoom en el timeline (botones y Ctrl+rueda), modos de fusion por capa,
rem  biblioteca de 8 presets de efecto, grupos de capas con
rem  multiseleccion (Ctrl+clic), atajos de teclado (pulsa ? para verlos)
rem  y exportar/importar efectos como .drexeffect.
rem  Ademas: login verificado (errores claros en tu idioma y detalle
rem  tecnico tras 2 intentos fallidos), gizmos sobre el preview, curvas
rem  de easing por keyframe, timeline multipista, mascaras con pluma y
rem  4 idiomas (ES/EN/ZH/PT).
rem  Novedades 1.5: pestana "Transmitir" para salir en vivo a Drex
rem  desde tu PC: camara, pantalla, videos, texto, chat y alertas en
rem  escenas con transiciones, todo en tu idioma.
rem ============================================================
start "" "%~dp0index.html"
