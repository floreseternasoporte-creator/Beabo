@echo off
rem ============================================================
rem  Drex Studio 1.3 — Launcher para Windows
rem  Abre la aplicacion en tu navegador predeterminado.
rem  Requiere conexion a internet (el backend de Drex es online).
rem  Novedades 1.3: login reparado de verdad (antes fallaba incluso con la
rem  contraseña correcta), errores claros en tu idioma y diagnóstico técnico
rem  tras 2 intentos fallidos. Además: gizmos sobre el preview, curvas de
rem  easing por keyframe, timeline multipista (video/efectos/texto/audio),
rem  mascaras con pluma, preview a resolucion real, bypass de cuenta oficial
rem  y 4 idiomas (ES/EN/ZH/PT).
rem ============================================================
start "" "%~dp0index.html"
