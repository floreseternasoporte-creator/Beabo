@echo off
rem ============================================================
rem  Drex Studio 1.2 — Launcher para Windows
rem  Abre la aplicacion en tu navegador predeterminado.
rem  Requiere conexion a internet (el backend de Drex es online).
rem  Novedades 1.2: gizmos sobre el preview, curvas de easing por
rem  keyframe, timeline multipista (video/efectos/texto/audio),
rem  mascaras con pluma, preview a resolucion real, bypass de
rem  cuenta oficial y 4 idiomas (ES/EN/ZH/PT).
rem ============================================================
start "" "%~dp0index.html"
